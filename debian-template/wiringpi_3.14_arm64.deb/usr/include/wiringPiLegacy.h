
const char* GetPiRevisionLegacy(char* line, int linelength, unsigned int* revision);